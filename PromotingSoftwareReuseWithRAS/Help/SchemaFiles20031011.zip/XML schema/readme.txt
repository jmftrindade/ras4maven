These are the original XML schema files that were produced by the RAS Consortium and refined in newer versions.

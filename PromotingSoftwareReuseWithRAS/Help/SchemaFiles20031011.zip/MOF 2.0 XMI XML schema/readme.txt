The MOF 2.0 XMI XML schemas in this directory we produced from a set of Rose models accompanying the RAS.

Each of the MOF 2.0 XMI XML schema files uses elements, rather than attributes, as the basis for capturing the meta data about assets.

Defaultcomponentprofile.xsd
Defaultprofile.xsd
Defaultwebserviceprofile.xsd
XMI.xsd

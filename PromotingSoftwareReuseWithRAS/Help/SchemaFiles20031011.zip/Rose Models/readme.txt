This describes the Rose models in this directory.

**********************************
*** RAS Default Profile Models ***
**********************************

1. RAS2.1_defaultprofile_target_XMLSchema.mdl: describes the profile from which the original XML schema file was produced

2. RAS2.1_defaultprofile_target_MOFXMIXMLSchema.mdl: describes the profile from which the MOF 2.0 XMI XML schema was produced

********************************************
*** RAS Default Component Profile Models ***
********************************************

3. RAS2.1_defaultcompprofile_target_XMLSchema.mdl: describes the profile from which the original XML schema file was produced

4. RAS2.1_defaultcompprofile_target_MOFXMIXMLSchema.mdl: describes the profile from which the MOF 2.0 XMI XML schema was produced

**********************************************
*** RAS Default Web Service Profile Models ***
**********************************************

5. RAS2.1_defaultwebsvcprofile_target_XMLSchema.mdl: describes the profile from which the original XML schema file was produced

6. RAS2.1_defaultwebsvcprofile_target_MOFXMIXMLSchema.mdl: describes the profile from which the MOF 2.0 XMI XML schema was produced
